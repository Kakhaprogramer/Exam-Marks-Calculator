package Kakha.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner s =new Scanner(System.in);

        System.out.println("Enter your name");

        String Studentname = s.nextLine();

        System.out.println("Enter your age");

        String Studentage = s.nextLine();

        System.out.println("Enter your English marks");

        float English = s.nextFloat();

        System.out.println("Enter your Math marks");

        float Math = s.nextFloat();

        System.out.println("Enter your Science marks");

        float Science = s.nextFloat();

        System.out.println("Enter your Religion marks");

        float Religion = s.nextFloat();

        float totalmarks = (English+Math+Science+Religion);

        double average = (totalmarks/4);

        System.out.println("Student name is");

        System.out.println(Studentname);

        System.out.println("Student age is");

        System.out.println(Studentage);

        System.out.println("Total marks is");

        System.out.println(totalmarks);

        System.out.println("Your average is");

        System.out.println(average);


    }
}
